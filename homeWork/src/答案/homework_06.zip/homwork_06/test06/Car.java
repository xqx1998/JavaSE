package homwork_06.test06;
/*定义汽车类Car,包含以下成员：
	 成员属性:
			品牌 brand( String类型)
			电量 power(double类型)
     成员方法:
			报警 warning()   调用方法,可以检验当前电量是否低于10,如果低于10,就打印"电量不足". 如果不低于10,就打印"电量充足"
		*/
public class Car {
    private String brand;
    private double power;

    public Car() {
    }

    public Car(String brand, double power) {
        this.brand = brand;
        this.power = power;
    }

    public String getBrand() {
        return brand;
    }

    public void setBrand(String brand) {
        this.brand = brand;
    }

    public double getPower() {
        return power;
    }

    public void setPower(double power) {
        this.power = power;
    }

    public void warning(){
        //判断当前电量是否小于10
        if(power<10){
            System.out.println("电量不足");
        }else {
            System.out.println("电量充足");
        }
    }
}
