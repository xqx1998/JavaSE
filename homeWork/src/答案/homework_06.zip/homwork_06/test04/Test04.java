package homwork_06.test04;
/*分析以下需求，并用代码实现
	定义人类Person,包含以下成员：
	 成员属性:
			姓名 name( String类型)
			年龄 age(double类型)

	1.按照以上要求定义Person,属性要私有,生成空参、有参构造，setter和getter方法
	2.定义测试类:根据如下需求创建多个对象(使用满参构造创建,即有参构造).
		老王-35    小芳-23
	3.通过两个对象,比较谁的年龄大,并打印出来.
		例:  老王年龄比较大*/
public class Test04 {
    public static void main(String[] args) {
        //利用给出的信息创建对象 老王-35    小芳-23  题目要求使用满参构造创建
        Person laowang = new Person("老王", 35);
        Person xiaofang = new Person("小芳", 23);

        //获得各自的年龄
        int age_lw = laowang.getAge();
        int age_xf = xiaofang.getAge();

        //判断谁的年龄大
        if(age_lw > age_xf){
            System.out.println(" 老王年龄比较大");
        }else{
            System.out.println(" 小芳年龄比较大");
        }

    }
}
