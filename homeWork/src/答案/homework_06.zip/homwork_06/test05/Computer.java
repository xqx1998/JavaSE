package homwork_06.test05;
/*1.定义“电脑类”Computer，包含以下成员：
         成员属性:
			品牌brand( String类型)
			价格 price(double类型)
         成员方法:
			编码coding(),  调用方法打印 ***电脑正在使用Java语言编程  ***代表品牌
			玩游戏,playGame()，调用方法打印 ***块钱的电脑正在玩王者荣耀s   ***代表价格*/
public class Computer {
    private String brand;
    private double price;

    public Computer() {
    }

    public Computer(String brand, double price) {
        this.brand = brand;
        this.price = price;
    }

    public String getBrand() {
        return brand;
    }

    public void setBrand(String brand) {
        this.brand = brand;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public void coding(){
        System.out.println(brand+"电脑正在使用Java语言编程");
    }

    public void playGame(){
        System.out.println(price+"块钱的电脑正在玩王者荣耀");
    }
}
