package homwork_06.test02;
/*狗类Dog
		属性:
			毛的颜色color
			品种breed
		行为:
			吃饭()
			看家lookHome()*/
public class Dog {
    //私有化属性
    private String color;
    private String bread;

    //空参构造
    public Dog() {
    }

    //有参构造
    public Dog(String color, String bread) {
        this.color = color;
        this.bread = bread;
    }

    //get/set方法
    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public String getBread() {
        return bread;
    }

    public void setBread(String bread) {
        this.bread = bread;
    }

    public void eat(){
        System.out.println(color+"的"+bread+"正在啃骨头.....");
    }

    public void lookHome(){
        System.out.println(color+"的"+bread+"正在看家.....");
    }

}
