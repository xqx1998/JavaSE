package homwork_06.test02;
/*1.猫类Cat
		属性:
			毛的颜色color
			品种bread
		行为:
			吃饭eat()
			抓老鼠catchMouse()*/
public class Cat {
    //私有化属性
    private String color;
    private String bread;

    //空参构造
    public Cat() {
    }

    //有参构造
    public Cat(String color, String bread) {
        this.color = color;
        this.bread = bread;
    }

    //get/set方法
    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public String getBread() {
        return bread;
    }

    public void setBread(String bread) {
        this.bread = bread;
    }

    //吃
    public void eat(){
        System.out.println(color+"的"+bread+"正在吃鱼.....");
    }

    //抓老鼠
    public void catchMouse(){
        System.out.println(color+"的"+bread+"正在逮老鼠....");
    }
}
