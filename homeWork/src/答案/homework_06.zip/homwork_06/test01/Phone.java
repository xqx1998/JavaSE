package homwork_06.test01;
/*手机类Phone
	属性:
		品牌brand
		价格price
	行为:
		打电话call()
		发短信sendMessage()
		玩游戏playGame()*/
public class Phone {
    //私有化属性
    private String brand;
    private int price;

    //空参构造
    public Phone() {
    }
    //有参构造
    public Phone(String brand, int price) {
        this.brand = brand;
        this.price = price;
    }

    //get/set方法
    public String getBrand() {
        return brand;
    }

    public void setBrand(String brand) {
        this.brand = brand;
    }

    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }

    //打电话
    public void call(){
        System.out.println("正在使用价格为"+price+"元的手机打电话....");
    }

    //发短信
    public void sendMessage(){
        System.out.println("正在使用"+brand+"品牌的手机发短信....");
    }

    //玩游戏
    public void playGame(){
        System.out.println("正在使用价格为"+price+"元的"+brand+"品牌的手机玩游戏....");
    }
}
