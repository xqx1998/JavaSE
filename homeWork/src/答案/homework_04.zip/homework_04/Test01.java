package homework;
/*分析以下需求，并用代码实现(每个小需求都需要封装成方法,并在main方法中调用)
	1.求两个数据之和(整数 小数),在main方法中打印出来
	2.判断两个数据是否相等(整数 整数),在控制台上打印出来
	3.获取两个数中较大的值(整数 小数),在控制台上打印出来
	4.获取两个数中较小的值(整数 整数),在main方法中打印出来*/
public class Test01 {
    public static void main(String[] args) {
        //.var
        double he = he(10, 20.0);
        System.out.println("he = " + he);


    }

    //求两个数据之和(整数 小数),在main方法中打印出来
    //有没有参数   有2个 int double
    //有没有返回值 有 double
    public static double he(int a,double b){
        double c = a+b;
        return c;
    }

}
