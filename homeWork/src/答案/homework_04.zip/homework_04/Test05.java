package homework;
/*1.定义一个方法,能够判断传入的int类型数据是不是偶数,返回true或false
	2.借用1中定义的方法,判断1-100中那些数字是偶数,并打印出来,求和.*/
public class Test05 {
    public static void main(String[] args) {
        //求和变量
        int sum = 0;
        for (int i = 1; i <= 100; i++) {
            boolean even = isEven(i);
            if(even == true){
                System.out.println(i);
                sum+=i;
            }
        }
        System.out.println(sum);
    }

    //定义一个方法,能够判断传入的int类型数据是不是偶数,返回true或false
    //参数 一个 int
    //返回值 有 boolean
    public static boolean isEven(int a){
        if(a%2==0){
            return true;
        }else{
            return false;
        }
    }
}
