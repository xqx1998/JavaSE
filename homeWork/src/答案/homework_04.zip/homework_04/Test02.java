package homework;
/*3.定义一个变量代表圆的半径(π取3.14)
		定义方法计算该圆的周长,并在main方法中打印周长(周长 = 2*π*半径)*/
public class Test02 {
    public static void main(String[] args) {
        int round = 1;
        double zc = getZC(round);
        System.out.println("zc = " + zc);
    }

    //定义方法计算该圆的周长,并在main方法中打印周长(周长 = 2*π*半径)
    //参数 一个参数 半径 int
    //返回值  有 double
    public static double getZC(int r){
        double zc = 2*3.14*r;
        return zc;
    }
}
