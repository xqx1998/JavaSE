package homework_07.Test01;
/*1.创建TPhone类，包含如下属性
  		品牌
  		价格
  		使用年限*/
public class TPhone {
    private String brand;
    private int price;
    private int userAge;

    public TPhone() {
    }

    public TPhone(String brand, int price, int userAge) {
        this.brand = brand;
        this.price = price;
        this.userAge = userAge;
    }

    public String getBrand() {
        return brand;
    }

    public void setBrand(String brand) {
        this.brand = brand;
    }

    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }

    public int getUserAge() {
        return userAge;
    }

    public void setUserAge(int userAge) {
        this.userAge = userAge;
    }
}
