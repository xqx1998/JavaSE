package homework_07.Test01;

import java.util.ArrayList;

/*
1.创建TPhone类，包含如下属性
  		品牌
  		价格
  		使用年限
2.在测试类中，利用满参构造创建4个对象，将对象存入集合中。
       华为-1200-4  苹果-9000-1  锤子-3000-3  小米-1800-2
3.遍历集合，将使用年限小于2或价格低于2000的手机筛选出来。
4.在控制台上打印所有筛选出来的对象（格式：华为-1200-4）*/
public class TPhoneTest {
    public static void main(String[] args) {
        //利用满参构造创建4个对象
        TPhone p1 = new TPhone("华为", 1200, 4);
        TPhone p2 = new TPhone("苹果", 9000, 1);
        TPhone p3 = new TPhone("锤子", 3000, 3);
        TPhone p4 = new TPhone("小米", 1800, 2);

        //创建集合
        ArrayList<TPhone> list = new ArrayList<>();

        //将对象转入集合
        list.add(p1);
        list.add(p2);
        list.add(p3);
        list.add(p4);

        //遍历集合  集合名.fori
        for (int i = 0; i < list.size(); i++) {
            //取出当前遍历的元素
            TPhone t = list.get(i);
            int price = t.getPrice(); //获取价格
            int userAge = t.getUserAge();//获取使用年限
            //筛选年限小于2或价格低于2000的手机
            if(userAge<2 || price<2000){
                //打印所有筛选出来的对象（格式：华为-1200-4）
                String brand = t.getBrand();//获取品牌
                //拼接打印
                System.out.println(brand+"-"+price+"-"+userAge);
            }

        }


    }
}
