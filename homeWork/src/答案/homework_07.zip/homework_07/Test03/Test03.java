package homework_07.Test03;

import java.util.ArrayList;

/*1.创建事务描述类Dog,包含空参构造、满参构造和以下成员变量:
			品种 kind  String类型
			年龄 age   int类型
			花色 color String类型
		生成以上成员的get/set方法

	在测试类中完成如下需求:
	2.根据以下信息通过满参构造创建三个对象,并将他们装入集合
		秋田犬-5-黄色  二哈-3-黑白  单身狗-23-黄色

	3.定义public static ArrayList<Dog> filter(ArrayList<Dog> list) {...}方法:
		要求：遍历list集合，将list中年龄大于10的元素存入到另一个ArrayList<Dog> 中并返回

	4.在main方法内调用filter方法传入2中的集合，根据返回的list集合输出元素信息
		示例如下：
			单身狗-23-黄色*/
public class Test03 {
    public static void main(String[] args) {
        // 根据信息创建三个对象
        Dog dog1 = new Dog("秋田犬",5,"黄色");
        Dog dog2 = new Dog("二哈",3,"黑白");
        Dog dog3 = new Dog("单身狗",23,"黄色");

        //创建集合  将创建的对象装入集合
        ArrayList<Dog> list = new ArrayList<>();
        list.add(dog1);
        list.add(dog2);
        list.add(dog3);

        //调用filter方法 将集合传入 获取返回的经过筛选的集合
        ArrayList<Dog> filter = filter(list);

        //遍历返回的集合  按照指定格式打印
        for (int i = 0; i < filter.size(); i++) {
            //获得集合中当前遍历的元素
            Dog dog = filter.get(i);
            //获得该元素(对象)的kind
            String kind = dog.getKind();
            //获得该元素(对象)的age
            int age = dog.getAge();
            //获得该元素(对象)的color
            String color = dog.getColor();
            //拼接打印
            System.out.println(kind+"-"+age+"-"+color);
        }
    }

    //定义方法
    public static ArrayList<Dog> filter(ArrayList<Dog> list) {
        //创建新集合
        ArrayList<Dog> list_new = new ArrayList<>();
        //遍历list集合
        for (int i = 0; i < list.size(); i++) {
            //获得集合中当前遍历的元素
            Dog dog = list.get(i);
            //获得该元素(对象)的年龄
            int age = dog.getAge();
            //判断该对象年龄是否大于10
            if(age > 10){
                //如果大于10 就将该元素存入新集合
                list_new.add(dog);
            }
        }
        //将新集合返回
        return list_new;
    }

}
