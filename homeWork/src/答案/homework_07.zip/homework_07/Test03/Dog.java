package homework_07.Test03;
/*创建事务描述类Dog,包含空参构造、满参构造和以下成员变量:
			品种 kind  String类型
			年龄 age   int类型
			花色 color String类型
		生成以上成员的get/set方法*/
public class Dog {
    private String kind;
    private int age;
    private String color;

    public Dog() {
    }

    public Dog(String kind, int age, String color) {
        this.kind = kind;
        this.age = age;
        this.color = color;
    }

    public String getKind() {
        return kind;
    }

    public void setKind(String kind) {
        this.kind = kind;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }
}
