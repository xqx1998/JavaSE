package homework_07.Test10;

import java.util.Scanner;

/*分析以下需求，并用代码实现
		1.创建一个储存整数的集合,键盘录入5个数据存入集合
		2.遍历集合,将集合中大于10的元素打印到控制台上,并求和.*/
public class Test10 {
    public static void main(String[] args) {
        int[] arr = new int[5];
        //键盘录入为数组赋值
        for(int i = 0;i<arr.length;i++){
            Scanner sc = new Scanner(System.in);
            int a = sc.nextInt();
            //将键盘录入的数赋值给数组当前元素
            arr[i] = a;
        }

        //遍历集合,将集合中大于10的元素打印到控制台上,并求和
        int sum = 0;
        for (int i = 0; i < arr.length; i++) {
            if(arr[i] > 10){
                System.out.println(arr[i]);
                sum += arr[i];
            }
        }
        System.out.println(sum);
    }
}
