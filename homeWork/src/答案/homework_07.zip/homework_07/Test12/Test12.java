package homework_07.Test12;

import java.util.ArrayList;

/*根据要求完成以下功能：
		a.定义ArrayList集合，存入如下整数：
			11，22， 55，66， 77 , 88
		b.遍历集合,删除大于60的元素,在控制台打印输出删除后的集合中所有元素*/
public class Test12 {
    public static void main(String[] args) {
        ArrayList<Integer> list = new ArrayList<>();
        list.add(11);
        list.add(22);
        list.add(55);
        list.add(66);
        list.add(77);
        list.add(88);

        //遍历集合,删除大于60的元素
        for (int i = 0; i < list.size(); i++) {
            Integer integer = list.get(i);
            if(integer > 60){
                list.remove(i);
                i--;
            }
        }

        //遍历集合  打印
        for (int i = 0; i < list.size(); i++) {
            Integer integer = list.get(i);
            System.out.println(integer);
        }
    }
}
