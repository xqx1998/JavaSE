package homework_07.Test02;
/*1.创建事务描述类Person,包含空参构造、满参构造和以下成员变量:
			学号 id    int类型
			姓名 name  String类型
			年龄 age   int类型
		生成以上成员的get/set方法*/
public class Person {
    private int id;
    private String name;
    private int age;

    public Person() {
    }

    public Person(int id, String name, int age) {
        this.id = id;
        this.name = name;
        this.age = age;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }
}
