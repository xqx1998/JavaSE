package homework_07.Test02;

import java.util.ArrayList;

/*	1.创建事务描述类Person,包含空参构造、满参构造和以下成员变量:
			学号 id    int类型
			姓名 name  String类型
			年龄 age   int类型
		生成以上成员的get/set方法

	2.根据以下信息创建三个对象,并将他们装入集合
		1-马尔扎哈-45  2-塔利斯塔-36  3-迪丽热巴-25

	3.遍历集合,将其中岁数小于30的对象删除,将余下的对象按照如下格式打印出来
		1-马尔扎哈-45*/
public class Test02 {
    public static void main(String[] args) {
        //根据信息创建三个对象
        Person person1 = new Person(1,"马尔扎哈",45);
        Person person2 = new Person(2,"塔利斯塔",36);
        Person person3 = new Person(3,"迪丽热巴",25);

        //创建集合  将创建的对象装入集合
        ArrayList<Person> list = new ArrayList<>();
        list.add(person1);
        list.add(person2);
        list.add(person3);

        //遍历集合 删除元素
        for (int i = 0; i < list.size(); i++) {
            //获得集合中当前遍历的元素
            Person person = list.get(i);
            //获得该元素(对象)的年龄
            int age = person.getAge();
            //判断该对象年龄是否小于30
            if(age < 30){
                //如果小于30,就想该对象删除
                list.remove(i);
                i--;
            }
        }

        //遍历集合  打印剩余的元素
        for (int i = 0; i < list.size(); i++) {
            //获得集合中当前遍历的元素
            Person person = list.get(i);
            //获得该元素(对象)的id
            int id = person.getId();
            //获得该元素(对象)的name
            String name = person.getName();
            //获得该元素(对象)的age
            int age = person.getAge();
            //拼接打印
            System.out.println(id+"-"+name+"-"+age);
        }
    }
}
