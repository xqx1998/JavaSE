package homework_07.Test05;

import java.util.ArrayList;

/*a.定义"电动汽车类"Ecar,包含:
		1)构造方法: 空参构造、满参构造；
		2)成员变量:
					品牌 brand（String类型）
					价格price（int类型）
					续航mile（int类型）；
		3)成员方法:所有成员变量的set/get方法；

	b.定义测试类EcarTest,完成以下需求:
		1)定义public static ArrayList<Ecar> filter(ArrayList<Ecar> list,int price ,int mile) 方法,
		要求:
			遍历list集合，将list中价格低于参数price,并且续航不低于参数mile的元素存入到另一个ArrayList<Ecar> 中并返回；

		2）定义main(String[] args)方法,要求:
			根据以下内容创建并初始化3个Ecar对象,
			{"威马EX5",179800,400},{"蔚来ES8", 448000,500},{"特斯拉ModelX",828000,552}，

		    创建一个ArrayList<Ecar> list，将上面的3个Ecar对象添加到list中，
			调用filter方法传入list_ecar,500000和400，根据返回的list集合输出所有元素信息；
		示例如下:
			威马EX5 179800元 400公里
			蔚来ES8 448000元 500公里*/
public class Test05 {
    public static void main(String[] args) {
// 根据信息创建三个对象
        Ecar ecar1 = new Ecar("威马EX5",179800,400);
        Ecar ecar2 = new Ecar("蔚来ES8",448000,500);
        Ecar ecar3 = new Ecar("特斯拉ModelX",828000,552);

        //创建集合  将创建的对象装入集合
        ArrayList<Ecar> list = new ArrayList<>();
        list.add(ecar1);
        list.add(ecar2);
        list.add(ecar3);

        //调用filter方法 将集合传入 获取返回的经过筛选的集合
        ArrayList<Ecar> filter = filter(list,500000,400);

        //遍历返回的集合  按照指定格式打印
        for (int i = 0; i < filter.size(); i++) {
            //获得集合中当前遍历的元素
            Ecar ecar = filter.get(i);
            //获得该元素(对象)的name
            int price = ecar.getPrice();
            //获得该元素(对象)的price
            int mile = ecar.getMile();
            //获得该元素(对象)的type
            String brand = ecar.getBrand();
            //拼接打印
            System.out.println(brand+"-"+price+"-"+mile);
        }

    }

    //定义方法
    public static ArrayList<Ecar> filter(ArrayList<Ecar> list,int price ,int mile){
        //创建新集合
        ArrayList<Ecar> list_new = new ArrayList<>();
        //遍历list集合
        for (int i = 0; i < list.size(); i++) {
            //获得集合中当前遍历的元素
            Ecar ecar = list.get(i);
            //获得该元素(对象)的价格
            int price_ecar = ecar.getPrice();
            //获得该元素的续航参数
            int mile_ecar = ecar.getMile();
            //判断该对象 是否 价格低于参数price,并且续航不低于参数mile
            if(price_ecar < price && mile_ecar >= mile){
                //如果满足条件 就将该元素存入新集合
                list_new.add(ecar);
            }
        }
        //将新集合返回
        return list_new;
    }
}
