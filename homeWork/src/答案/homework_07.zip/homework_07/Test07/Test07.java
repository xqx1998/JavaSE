package homework_07.Test07;

import java.util.Scanner;

/*1.定义方法 isSXH(int num)
		功能:判断数字num是否是水仙花数,如果是返回true,如果不是返回false
	2.在主方法中,键盘录入数据,调用isSXH方法,判断传入的数据是否为水仙花数,如果是就输出"xxx为水仙花数",否则就输出"xxx不是水仙花数"
		演示:
			  请输入一个三位整数:
			  100
			  100不是水仙花数*/
public class Test07 {
    public static void main(String[] args) {
        //,键盘录入数据
        Scanner scanner = new Scanner(System.in);
        int i = scanner.nextInt();
        //调用isSXH方法,判断传入的数据是否为水仙花数
        boolean sxh = isSXH(i);
        if(sxh == true){
            System.out.println(i+"为水仙花数");
        }else{
            System.out.println(i+"不是水仙花数");
        }
    }

    //定义方法 isSXH(int num) 功能:判断数字num是否是水仙花数,如果是返回true,如果不是返回false
    //参数 有1个 int num
    //返回值  有  boolean
    public static boolean isSXH(int num){
        //求个  十  百
        int ge = num%10;
        int shi = num/10%10;
        int bai = num/10/10%10;
        if(ge*ge*ge+shi*shi*shi+bai*bai*bai == num){
            return  true;
        }else{
            return false;
        }
    }
}
