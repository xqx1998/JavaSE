package homework_07.Test06;

import java.util.ArrayList;

/* 1.创建Student类，包含如下属性
  		姓名
  		年龄
  		学历
	  2.在测试类中，利用满参构造创建3个对象，将对象存入集合中。
		小红  12 小学          小米 21 大学        小明 14 初中
	  3.遍历集合，将年龄小于15的人的学历改为幼儿园。
	  4.在控制台上打印所有对象（格式：小红-12-幼儿园）*/
public class Test06 {
    public static void main(String[] args) {
        //利用满参构造创建3个对象，将对象存入集合中
        Student student1 = new Student("小红", 12, "小学");
        Student student2 = new Student("小米", 21, "大学  ");
        Student student3 = new Student("小明", 14, "初中");

        //创建集合 将创建的对象装入集合
        ArrayList<Student> list = new ArrayList<>();
        list.add(student1);
        list.add(student2);
        list.add(student3);

        //遍历集合，将年龄小于15的人的学历改为幼儿园
        for (int i = 0; i < list.size(); i++) {
            //获得集合中当前遍历的元素
            Student student = list.get(i);
            //获得元素的年龄
            int age = student.getAge();
            //判断年龄是否小于15
            if(age < 15){
                //如果满足条件  就将该对象的学历改为幼儿园
                student.setXueli("幼儿园");
            }
        }

        //遍历集合  按照指定格式打印
        for (int i = 0; i < list.size(); i++) {
            //获得集合中当前遍历的元素
            Student student = list.get(i);
            //获得该元素(对象)age
            int age = student.getAge();
            //获得该元素(对象)name
            String name = student.getName();
            //获得该元素(对象)xueli
            String xueli = student.getXueli();

            //拼接打印
            System.out.println(name+"-"+age+"-"+xueli);
        }

    }
}
