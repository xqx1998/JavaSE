package homework_07.Test11;

import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;

/*分析一下需求,并用代码实现
		1.创建一个储存整数的集合,随机产生10个两位数存入集合
		2.定义一个方法,将集合传入,筛选出其中所有小于50的元素,存入新的集合中,将新集合返回
		3.在主方法中,调用2中的方法,将1中的集合传入,得到返回的集合,将返回的集合遍历打印.*/
public class Test11 {
    public static void main(String[] args) {
        ArrayList<Integer> list = new ArrayList<>();

        //随机数为集合赋值
        for(int i = 0;i <10;i++){
            Random random = new Random();
            int a = random.nextInt(100);
            //将键盘录入的数添加到list集合中
            list.add(a);
        }

        //调用2中的方法,将1中的集合传入,得到返回的集合,将返回的集合遍历打印
        ArrayList<Integer> filter = filter(list);

        for (int i = 0; i < filter.size(); i++) {
            Integer integer = filter.get(i);
            System.out.println(integer);
        }


    }

    public static ArrayList<Integer> filter(ArrayList<Integer> list){
        ArrayList<Integer> list_new = new ArrayList<>();
        for (int i = 0; i < list.size(); i++) {
            Integer integer = list.get(i);
            if(integer<50){
                list_new.add(integer);
            }
        }
        return list_new;
    }
}
