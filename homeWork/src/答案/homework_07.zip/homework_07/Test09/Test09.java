package homework_07.Test09;

import java.util.Random;

/*分析以下需求，并用代码实现
		1.创建两个长度为5的数组，数组内元素为随机生成的 1-100之间的偶数。(r.nextInt(50)+1)*2
		2.定义一个方法hebin(描述如下)，传入两个数组，方法中将两个数组元素合并到一个新数组中，并且将新数组的内容打印到控制台上
*/
public class Test09 {
    public static void main(String[] args) {
        int[] arr1 = new int[5];
        int[] arr2 = new int[5];

        //用随机数给数组赋值
        for(int i = 0;i<arr1.length;i++){
            Random r = new Random();
            int a = (r.nextInt(50)+1)*2;
            //将产生的随机数赋值给数组当前元素
            arr1[i] = a;
        }

        for(int i = 0;i<arr2.length;i++){
            Random r = new Random();
            int a = (r.nextInt(50)+1)*2;
            //将产生的随机数赋值给数组当前元素
            arr2[i] = a;
        }

        //调用方法 合并数组
        int[] hebin = hebin(arr1, arr2);

        //遍历数组 打印
        for (int i = 0; i < hebin.length; i++) {
            System.out.println(hebin[i]);
        }


    }

    //要求定义一个方法,将上面两个数组传入,在方法中将两个数组合并,形成一个新的数组,并返回.
    //参数 有 2个 int[]
    //返回值 有 int[]
    public static int[] hebin(int[] arr1,int[] arr2){
        //定义新数组
        int[] arr3 = new int[arr1.length+arr2.length];
        //{0,0,0,0,0,0}

        //arr1 -> arr3
        for (int i = 0; i < arr1.length; i++) {
            arr3[i] = arr1[i];
        }
        //{1,2,3,0,0,0}

        //arr2 -> arr3
        for (int i = 0; i < arr2.length; i++) {
            arr3[arr1.length+i] = arr2[i];
        }
        //{1,2,3,4,5,6}

        return arr3;
    }
}
