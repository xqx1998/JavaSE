package com.homework_08;

import java.util.ArrayList;

/*a.定义方法public static ArrayList<String>  handleString(String [] arr，String str)；
		实现以下功能：
			遍历arr，将数组中包含参数str的元素,含有str的部分替换为*, 存入另一个集合中,将新集合返回；
	b.在main方法中完成以下要求：
		1)定义一个String数组arr，数组元素有："beijing", "shanghai", "tianjin", "chongqing"；
		2)调用handleString方法传入arr数组和字符串”a”，输出返回的集合中所有元素；

	示例如下：
			控制台输出元素如下:
			[sh*ngh*i,ti*njin]*/
public class StringDemo9 {
    public static void main(String[] args) {
        String[] arr = {"beijing", "shanghai", "tianjin", "chongqing"};
        //调用方法 传入准备好的数组
        ArrayList<String> list = handleString(arr, "a");
        //打印返回的集合
        System.out.println(list);
    }

    public static ArrayList<String> handleString(String [] arr,String str){
        //准备好集合 来存储符合条件的字符串
        ArrayList<String> list = new ArrayList<>();
        //遍历arr
        for (int i = 0; i < arr.length; i++) {
            //获取当前遍历的元素
            String s = arr[i];
            //判断当前元素中是否包含字符串str  假如不包含就会返回-1
            int a = s.indexOf(str);
            //假如返回的不是-1  就代表包含字符串str
            if(a != -1){
                //满足条件  包含字符串str 就将当前元素含有str的部分替换为*
                String replace = s.replace(str, "*");
                //将改变后的元素存入集合
                list.add(replace);
            }
        }
        return list;
    }
}
