package com.homework_08;

import java.util.Scanner;

/*1.键盘录入一个字符串
	2.统计录入的字符串中的大写字母,小写字母,数字分别有多少个.*/
public class StringDemo2 {
    public static void main(String[] args) {
        //键盘录入一个字符串
        System.out.println("请输入一个字符串");
        Scanner scanner = new Scanner(System.in);
        String s = scanner.nextLine();
        //统计录入的字符串中的大写字母,小写字母,数字分别有多少个
        int bigcount = 0;
        int smallcount = 0;
        int numbercount = 0;
        //遍历字符串
       /* //将字符串转为字符数组
        char[] chars = s.toCharArray();
        //遍历字符数组
        for (int i = 0; i < chars.length; i++) {
            //判断当前字符是大写还是小写,还是数字
            if(chars[i]>='A'&& chars[i]<='Z' ){
                bigcount++;
            }else if(chars[i]>='a'&& chars[i]<='z' ){
                smallcount++;
            }else{
                numbercount++;
            }
        }*/
		//遍历字符串
        for (int i = 0; i < s.length(); i++) {
			//获取字符串当前索引对应的字符
            char c = s.charAt(i);
			//判断字符范围
            if(c>='A'&&c<='Z' ){
                bigcount++;
            }else if(c>='a'&& c<='z' ){
                smallcount++;
            }else{
                numbercount++;
            }
        }
        System.out.println("大写"+bigcount);
        System.out.println("小写"+smallcount);
        System.out.println("数字"+numbercount);

    }

}
