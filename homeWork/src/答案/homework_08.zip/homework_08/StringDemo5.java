package com.homework_08;

import java.util.Random;
import java.util.Scanner;

/*1.键盘录入一个字符串
	2.从字符串中随机获取3次字符,将获取的3个字符组成一个新的字符串.打印到控制台上*/
public class StringDemo5 {
    public static void main(String[] args) {
        System.out.println("请输入一个字符串:");
        Scanner scanner = new Scanner(System.in);
        String s = scanner.nextLine();

        //生成三个随机数,范围是该字符串的索引范围  0 ~ s.length-1
        Random random = new Random();
        int i1 = random.nextInt(s.length());
        int i2 = random.nextInt(s.length());
        int i3 = random.nextInt(s.length());

        //根据生成的随机索引 得到字符串中的随机元素
        char c1 = s.charAt(i1);
        char c2 = s.charAt(i2);
        char c3 = s.charAt(i3);

        //将得到的三个字符拼接起来
        String str = ""+c1+c2+c3;

        System.out.println(str);

        //方法二:
        //进阶版写法
       /* String str = "";
        //用循环 得到三次随机元素  用字符串拼接起来  原理相当于求和思想
        for (int i = 0; i < 3; i++) {
            Random random = new Random();
            int ran = random.nextInt(s.length());
            char c = s.charAt(ran);
            str += c;
        }
        System.out.println(str);*/
    }
}
