package com.homework_08;

import java.util.ArrayList;

/*完成下列题目要求：
		①定义方法filter
			要求如下：
				参数：String[] arr，String  str
				返回值类型：String[]
			实现：遍历arr，将数组中包含参数str的元素存入另一个String 数组中并返回
			PS：返回的数组长度需要用代码获取
		②在main方法中完成以下要求：
			定义一个String数组arr，数组元素有："itcast","itheima","baitdu","weixin","zhifubao"
			调用1中的filter方法传入arr数组和字符串”it”，输出返回的String数组中所有元素
		示例如下：
			输出的数组中的元素:
			"itcast","itheima","baitdu"*/
public class StringDemo8 {
    public static void main(String[] args) {
        String[] arr = {"itcast","itheima","baitdu","weixin","zhifubao"};
        //调用方法 传入准备好的数组
        String[] its = filter(arr, "it");
        //遍历打印返回的数组
        for (int i = 0; i < its.length; i++) {
            System.out.print(its[i]+"  ");
        }
    }

    public static String[] filter(String[] arr ,String  str){
        //准备好集合 来存储符合条件的字符串
        ArrayList<String> list = new ArrayList<>();
        //遍历传入的数组
        for (int i = 0; i < arr.length; i++) {
            //获取当前遍历的元素
            String s = arr[i];
            //判断当前元素中是否包含字符串str  假如不包含就会返回-1
            int a = s.indexOf(str);
            //假如返回的不是-1  就代表包含字符串str
            if(a != -1){
                //满足条件  包含字符串str 就将当前元素存入集合中
                list.add(s);
            }
        }

        //将集合中的元素存入数组
        //根据集合的长度创建对应容量的数组
        String[] arr_new = new String[list.size()];
        //将集合中的元素一一对应的复制到数组中
        for (int i = 0; i < list.size(); i++) {
            arr_new[i] = list.get(i);
        }

        return arr_new;
    }
}
