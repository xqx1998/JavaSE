package com.homework_08;
/*分析以下需求，并用代码实现
	1.定义如下方法public static String getPropertyGetMethodName(String property)
		功能描述:
			(1)该方法的参数为String类型，表示用户传入的参数，返回值类型为String类型，返回值为对应的get方法的名字
			(2)如：用户调用此方法时传入参数为"name",该方法的返回值为"getName"
								   传入参数为"age",该方法的返回值为"getAge"

	2.定义如下方法public static String getPropertySetMethodName(String property)
		功能描述:
			(1)该方法的参数为String类型，表示用户传入的参数，返回值类型为String类型，返回值为对应的set方法的名字
			(2)如：用户调用此方法时传入参数为"name",该方法的返回值为"setName"
								   传入参数为"age",该方法的返回值为"setAge"*/
public class StringDemo7 {
    public static void main(String[] args) {
        String name = getPropertyGetMethodName("name");
        System.out.println(name);

        String age = getPropertySetMethodName("age");
        System.out.println(age);

    }

    public static String getPropertyGetMethodName(String property){
        //想要将 name 变为 getName
        //1将 name 截取成 n 和 ame
        String substring1 = property.substring(0, 1); //n
        String substring2 = property.substring(1, property.length());//ame
        //2.将n变成大写N
        String substring1_up = substring1.toUpperCase();//N
        //3.将大写后的N与ame拼接起来  形成 Name
        String str_new = substring1_up+substring2;//Name
        //4.在Name前面拼接上get  得到getName
        String str = "get"+str_new;

        return str;
    }

    public static String getPropertySetMethodName(String property){
        //想要将 name 变为 setName
        //1将 name 截取成 n 和 ame
        String substring1 = property.substring(0, 1); //n
        String substring2 = property.substring(1, property.length());//ame
        //2.将n变成大写N
        String substring1_up = substring1.toUpperCase();//N
        //3.将大写后的N与ame拼接起来  形成 Name
        String str_new = substring1_up+substring2;//Name
        //4.在Name前面拼接上set  得到getName
        String str = "set"+str_new;

        return str;
    }
}
