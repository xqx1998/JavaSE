package com.homework_08;

import java.util.Scanner;

/*第三题:
	1.键盘录入5个字符串,组成一个数组
	2.统计录入的字符串数组中的大写字母,小写字母,数字分别有多少个.*/
public class StringDemo3 {
    public static void main(String[] args) {
        //键盘录入5个字符串,组成一个数组
        String[] arr = new String[5];
        for(int i = 0;i<arr.length;i++){
            Scanner sc = new Scanner(System.in);
            String s = sc.nextLine();
            //将键盘录入的字符串赋值给数组当前元素
            arr[i] = s;
        }

        //统计录入的字符串数组中的大写字母,小写字母,数字分别有多少个.
        //将字符串数组中的内容拼接成一个字符串
        String str = "";
        for (int i = 0; i < arr.length; i++) {
            str += arr[i];
        }

        //遍历拼接好的字符串str 统计大写字母,小写字母,数字分别有多少个
        int bigcount = 0;
        int smallcount = 0;
        int numbercount = 0;
        //遍历字符串
        for (int i = 0; i < str.length(); i++) {
            //获取字符串当前索引对应的字符
            char c = str.charAt(i);
            //判断字符范围
            if(c>='A'&&c<='Z' ){
                bigcount++;
            }else if(c>='a'&& c<='z' ){
                smallcount++;
            }else{
                numbercount++;
            }
        }
        System.out.println("大写"+bigcount);
        System.out.println("小写"+smallcount);
        System.out.println("数字"+numbercount);
    }
}
