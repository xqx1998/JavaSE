package com.homework_08;

import java.util.Scanner;

/*1.键盘录入一个字符串
	2.将该字符串变成字符数组
	3.将字符数组中的所有大写字母变成小写字母
	4.如果第一位和最后一位的内容不相同,则交换
	5.将字符数组中索引为偶数的元素变成'~'
	6.打印数组元素的内容
	------------------------------
	【结果展示】
			请输入字符串
				abcDEf719
			最终显示的效果
				~b~d~f~1~*/
public class StringDemo4 {
    public static void main(String[] args) {
        System.out.println("请输入一个字符串:");
        Scanner scanner = new Scanner(System.in);
        String s = scanner.nextLine();

        //将该字符串变成字符数组
        char[] chars = s.toCharArray();

        //将字符数组中的所有大写字母变成小写字母
        //遍历字符数组
        for (int i = 0; i < chars.length; i++) {
            //判断当前字符是否为大写
            if(chars[i] >= 'A' && chars[i] <= 'Z'){
                //假如为大写 就变为小写  加上 32就行
                chars[i] += 32;
            }
        }

        //如果第一位和最后一位的内容不相同,则交换
        if(chars[0] != chars[chars.length-1]){
            //第三方变量交换 第一个元素 与 最后一个元素
            char temp = chars[0];
            chars[0] =  chars[chars.length-1];
            chars[chars.length-1] = temp;

        }

        //将字符数组中索引为偶数的元素变成'~'
        //遍历字符数组
        for (int i = 0; i < chars.length; i++) {
            //判断索引是否为偶数
            if(i%2==0){
                //如果为偶数  就将索引对应的数组中的元素改为'~'
                chars[i] = '~';
            }
        }

        //打印数组元素的内容
        for (int i = 0; i < chars.length; i++) {
            System.out.println(chars[i]);
        }
    }
}
