package com.homework_08;

import java.util.ArrayList;
import java.util.Scanner;

/*1.创建一个集合,往集合中键盘录入5个字符串
	2.遍历集合,将集合中长度大于4的元素末尾加上一个X,
	3.遍历集合,将集合打印在控制台上.
	例:键盘录入后的集合{"123","ASDFQ","qq","poiuy","asd"}
	打印到控制台上的集合{"123","ASDFQX","qq","poiuyX","asd"}*/
public class StringDemo6 {
    public static void main(String[] args) {
        //创建一个集合
        ArrayList<String> list = new ArrayList<>();
        //集合中键盘录入5个字符串
        for (int i = 0; i < 5; i++) {
            Scanner scanner = new Scanner(System.in);
            String s = scanner.nextLine();
            list.add(s);
        }
        //遍历集合,将集合中长度大于4的元素末尾加上一个X,
        for (int i = 0; i < list.size(); i++) {
            String s = list.get(i);
            //如果长度大于4
            if(s.length()>4){
                //将该元素加上"X"
                s += "X";
                //再将改变后的元素设置回集合
                list.set(i,s);
            }
        }
        //打印输出  假如集合存储出的是基本数据类型或字符串  既可以直接打印集合  假如是存储的是对象,就不能直接打印
        System.out.println(list);

    }
}
