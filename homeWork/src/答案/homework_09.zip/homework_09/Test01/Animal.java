package com.homework_09.Test01;
/*1.定义一个Animal类,包含如下行为:
		eat()  打印"要吃饭"
		run()  打印"会跑步"
		sleep() 打印"要睡觉"
	*/
public class Animal {
    public void eat(){
        System.out.println("要吃饭");
    }

    public void run(){
        System.out.println("会跑步");
    }

    public void sleep(){
        System.out.println("要睡觉");
    }
}
